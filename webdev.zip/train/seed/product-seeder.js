var Product = require('../models/product');

var mongoose = require('mongoose');

mongoose.connect('mongodb://127.0.0.1:27017/shop', {useNewUrlParser: true});

var products = [
    new Product({
        image: 'https://gymbeambg.vshcdn.net/media/catalog/product/cache/926507dc7f93631a094422215b778fe0/w/h/whey_proffesional_chocolate_scitec_nutrition.png',
        title: 'Gold Standard 100% Whey',
        description: 'Muscle Building Whey Protein Powder',
        category: 'amsalak',
        price: 30
    })   
];

var done = 0
for (var i = 0; i < products.length; i++) {
    products[i].save(function(err, result) {
        done++;
        if (done === products.length) {
            exit();
        }
    });
}
function exit() {
    mongoose.disconnect();
}