var inp = document.getElementById('input');
var result = document.getElementById('result');
var symbol = sym => {       
    switch(sym){
        case 1:
            inp.value += '1';
            break;
        case 2:
            inp.value += '2';
            break;
        case 3:
            inp.value += '3';
            break;
        case 4:
            inp.value += '4';
            break;
        case 5:
            inp.value += '5';
            break;
        case 6:
            inp.value += '6';
            break;
        case 7:
            inp.value += '7';
            break;
        case 8:
            inp.value += '8';
            break;
        case 9:
            inp.value += '9';
            break;
        case 0:
            inp.value += '0';
            break;
        case '-':
            inp.value += '-';
            break;                                        
        case '+':
            inp.value += '+';
            break;
        case '*':
            inp.value += '*';
            break;
        case '/':
            inp.value += '/';
            break;
        case '.':
            inp.value += '.';
            break;    
    }
}
var clean = () => {
    inp.value = "";
    result.value = "";
}
var calc = () => {
    var res = Math.round(eval(inp.value)*100)/100;
    result.value = res;
}
