            // Create an object:
            var person = ['bogo', 'go6o']
              
              // Display some data from the object:
              document.getElementById("demo").innerHTML =
              person;